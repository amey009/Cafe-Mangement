package com.m13.cafe.constants;

public class CafeConstants {

    public static final String SOMETHING_WENT_WRONG=" Something Went Wrong....!";

    public static final String INVALID_DATA="Invalid data....!";

    public static final String UNAUTHORIZED="Unauthorized....!";

    public static final String STORE_LOCATION="C:\\Users\\Amey\\cafe\\src\\main\\Bill pdf";
}
